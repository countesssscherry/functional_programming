n = 100
number = 35
i = 0
fib1 = 1
fib2 = 1

while i < n - 2:
    fib_sum = fib1 + fib2
    fib1 = fib2
    fib2 = fib_sum
    if (fib1 > number):
        print(i)
        break
    elif (fib2 > number):
        print(i)
        break
    i = i + 1
