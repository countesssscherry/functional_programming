module Main where

getVars :: Integer -> Integer -> Integer -> Integer -> Integer
getVars x y z m = ((m `div` x) - ((m - m `div` x) `div` y)) `div` z

fibs :: [Int]
fibs = 1 : 1 : zipWith (+) fibs (tail fibs)

fibo a b = a:fibo b (a+b)

-- for getting elem of array
nthElemNum :: [Int] -> Int -> Int
-- nthElemNum l x y z = length(filter (\n -> ((divisibleBy n x) || (divisibleBy n y) || (divisibleBy n z))) l) 
nthElemNum l n = length(filter (<n) l)

-- fibo -> x -> y -> z
getAllDivs :: [Int] -> Int -> Int -> Int -> Int
getAllDivs l x y z = length( (filter (\n -> (divisibleBy n x) ) l) ++ (filter (\n -> (divisibleBy n y) ) l) ++ (filter (\n -> (divisibleBy n z) ) l))

divisibleBy x x2 = x `rem` x2 == 0

getTimes x y z m = getAllDivs (take (nthElemNum (take 100 (fibo 0 1)) m) (fibo 0 1)) x y z

main :: IO ()
--main = print(getAllDivs (take (nthElemNum (take 100 (fibo 0 1)) 35) (fibo 0 1)) 5 4 3) 
main = do
    putStrLn ""
    putStrLn "for numbers 50 5 4 3"
    print(getTimes 50 5 4 3) 
