module Main where

nOfNeg l = length(filter (>0) l)

fromDecimal :: Int -> [Int]
fromDecimal 0 = [0]
-- fromDecimal n = showIntAtBase 2 intToDigit n 
fromDecimal n = mod n 2 : fromDecimal (div n 2)

main :: IO ()
main = do
    putStrLn ""
    putStrLn ""
    putStrLn "Chosen number 5"
    print ("number of ones: " ++ show (nOfNeg (fromDecimal 5)))
    putStrLn ""
    putStrLn ""
