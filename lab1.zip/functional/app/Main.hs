module Main where

import Numeric (showHex, showIntAtBase)
import Data.Char (intToDigit)
import Control.Monad 

fromBinary :: String -> Int
fromBinary = foldr (\c s -> s * 2 + c) 0 . reverse . map c2i
    where c2i c = if c == '0' then 0 else 1

fromDecimal :: Int -> [Int]
fromDecimal 0 = [0]
-- fromDecimal n = showIntAtBase 2 intToDigit n 
fromDecimal n = mod n 2 : fromDecimal (div n 2)

addOneToArray :: [Int] -> [Int]
addOneToArray n = init n ++ [1]

substractOneFromArray :: [Int] -> [Int]
substractOneFromArray n = init n

andOperator :: [Int] -> [Int] -> [Int]
andOperator = zipWith (*)

countOnes :: [Int] -> Int
countOnes [0] = 0
countOnes n = 1 + (countOnes (andOperator n ((fromDecimal ((fromBinary (show n)) - 1)))))

main :: IO ()
main = print (countOnes (fromDecimal 5))

